from django.db import models

# Create your models here.
class od2019(models.Model):
	name =models.CharField(max_length=20)
	department =models.CharField(max_length=30)
	university =models.CharField(max_length=50)
	duration=models.CharField(max_length=20)
	research=models.CharField(max_length=300)
	photo=models.CharField(max_length=20)
class od2018(models.Model):
	name =models.CharField(max_length=20)
	department =models.CharField(max_length=30)
	university =models.CharField(max_length=50)
	duration=models.CharField(max_length=20)
	research=models.CharField(max_length=300)
	photo=models.CharField(max_length=20)
class od2017(models.Model):
	name =models.CharField(max_length=20)
	department =models.CharField(max_length=30)
	university =models.CharField(max_length=50)
	duration=models.CharField(max_length=20)
	research=models.CharField(max_length=300)
	photo=models.CharField(max_length=20)
class od2016(models.Model):
	name =models.CharField(max_length=20)
	department =models.CharField(max_length=30)
	university =models.CharField(max_length=50)
	duration=models.CharField(max_length=20)
	research=models.CharField(max_length=300)
	photo=models.CharField(max_length=20)
class od2015(models.Model):
	name =models.CharField(max_length=20)
	department =models.CharField(max_length=30)
	university =models.CharField(max_length=50)
	duration=models.CharField(max_length=20)
	research=models.CharField(max_length=300)
	photo=models.CharField(max_length=20)
