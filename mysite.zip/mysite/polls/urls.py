from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('outbound_2019/',views.subindex_1,name='subindex_1'),
    path('outbound_2018/',views.subindex_2,name='subindex_2'),
    path('outbound_2017/',views.subindex_3,name='subindex_3'),
    path('outbound_2016/',views.subindex_4,name='subindex_4'),
    path('outbound_2015/',views.subindex_5,name='subindex_5'),
]
