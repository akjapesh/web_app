from django.shortcuts import render
from django.template import loader
from .models import od2019,od2018,od2017,od2016,od2015
# Create your views here.
from django.http import HttpResponse


def index(request):
    template=loader.get_template('/home/abhinav/py/django/mysite/polls/templates/ir/doc.html')
    return HttpResponse(template.render())
def subindex_1(request):
    odlist =od2019.objects.all()
    return render(request,'/home/abhinav/py/django/mysite/polls/templates/ir/outbound.html',{'students':odlist})
def subindex_2(request):
    odlist =od2018.objects.all()
    return render(request,'/home/abhinav/py/django/mysite/polls/templates/ir/outbound.html',{'students':odlist})
def subindex_3(request):
    odlist =od2017.objects.all()
    return render(request,'/home/abhinav/py/django/mysite/polls/templates/ir/outbound.html',{'students':odlist})
def subindex_4(request):
    odlist =od2016.objects.all()
    return render(request,'/home/abhinav/py/django/mysite/polls/templates/ir/outbound.html',{'students':odlist})
def subindex_5(request):
    odlist =od2015.objects.all()
    return render(request,'/home/abhinav/py/django/mysite/polls/templates/ir/outbound.html',{'students':odlist})
